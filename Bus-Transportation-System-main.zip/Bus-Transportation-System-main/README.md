# Bus Transportation System

It's an application used to make the college bus transportation system efficient.

ER DIAGRAM
![image](https://github.com/Laya-Shree/Bus-Transportation-System/assets/113045112/dcc2a13e-fe43-47d8-9bb5-b373fe13a864)

HOME PAGE
![image](https://github.com/Laya-Shree/Bus-Transportation-System/assets/113045112/a63d0516-f852-43aa-9a6d-3f57735dd53e)

ADMIN PAGE
![image](https://github.com/Laya-Shree/Bus-Transportation-System/assets/113045112/543945bf-d70d-4014-95f4-1f9f0399fa21)

ADMIN - UPDATING DRIVER DETAILS
![image](https://github.com/Laya-Shree/Bus-Transportation-System/assets/113045112/e6a7440e-b29d-4133-a51e-32f69edaeb37)

ADMIN - VIEWING STUDENTS WITH PENDING FEE
![image](https://github.com/Laya-Shree/Bus-Transportation-System/assets/113045112/bd2e4e08-51a4-4fef-af74-c103e7e39e2a)

ADMIN - MAKE ANNOUNCEMENTS
![image](https://github.com/Laya-Shree/Bus-Transportation-System/assets/113045112/3f5f9bb6-1895-4f3a-9c6b-a77a67cd481a)

DRIVER PAGE
![image](https://github.com/Laya-Shree/Bus-Transportation-System/assets/113045112/fc57e171-7d19-4b52-8c1f-44822ba7a927)

DRIVER PAGE - PASSENGERS NOT USING TRANSPORT ON THAT DAY
![image](https://github.com/Laya-Shree/Bus-Transportation-System/assets/113045112/f438ea8c-8e73-4d2c-88ae-025e0dbfad50)

STUDENT PAGE
![image](https://github.com/Laya-Shree/Bus-Transportation-System/assets/113045112/ab1b0c4d-d751-4a18-8aa9-735548dfa964)

STUDENT - PAYMENT PAGE
![image](https://github.com/Laya-Shree/Bus-Transportation-System/assets/113045112/360803e8-bd4c-4744-b1b4-755aa433ee72)

STUDENT - RESERVATION PAGE
![image](https://github.com/Laya-Shree/Bus-Transportation-System/assets/113045112/2933d6d9-9e30-4d3f-9f9a-c12b5abfdfd7)

STUDENT - NOTIFYING THE DRIVER WHEN NOT USING TRANSPORT
![image](https://github.com/Laya-Shree/Bus-Transportation-System/assets/113045112/8cbb4aeb-b1f2-4513-a997-b5fbccd9c6dc)











