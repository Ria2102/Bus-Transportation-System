package GUI;

public class DateStore {
    static String h;
    public void setdate(String d){
        h = d;
    }
    public String getDate(){
        return h;
    }
}
